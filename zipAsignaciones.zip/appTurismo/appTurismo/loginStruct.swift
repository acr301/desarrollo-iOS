//
//  loginStruct.swift
//  appTurismo
//
//  Created by user263366 on 9/9/24.
//

import Foundation

struct loginCredencialesModelo {
    let username: String
    let password: String
}


